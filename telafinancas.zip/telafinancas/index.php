<?php
    session_start();

    if (isset($_SESSION['id']) && isset($_SESSION['role'])) {

    // Inclui a conexão com a base de dados
    require_once('dbconnection.php');

    // Código para obter os totais
    try {
        // Total de alunos
        $stmt = $conn->query("SELECT COUNT(*) AS total FROM estudantes");
        $totalAlunos = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

        // Total de professores
        $stmt = $conn->query("SELECT COUNT(*) AS total FROM professores");
        $totalProfessores = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

        // Total de turmas
        $stmt = $conn->query("SELECT COUNT(*) AS total FROM turma");
        $totalTurmas = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

    } catch (PDOException $e) {
        echo "Erro ao buscar dados: " . $e->getMessage();
        $totalAlunos = $totalProfessores = $totalTurmas = 0;
    }
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Financeiro - Escola</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
</head>
<body>
    <div class="container">
        <!-- Sidebar Menu -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <h2>Pitruca <br>Camama</h2>
                <span class="material-symbols-outlined menu-toggle" id="menuToggle">menu</span>
            </div>
            <div class="profile">
                <div class="profile-info">
                    <span><?php echo $_SESSION['fname']; ?></span>
                    <p>Gerente Financeiro</p>
                </div>
            </div>
            <nav class="menu">
    <ul>
        <li class="active">
            <a href="index.php">
                <span class="material-symbols-outlined">dashboard</span>
                <span class="menu-text">Dashboard</span>
            </a>
        </li>
        <li>
            <a href="mensalidades.php">
                <span class="material-symbols-outlined">payments</span>
                <span class="menu-text">Mensalidades</span>
            </a>
        </li>
        <li>
            <a href="inadimplencia.php">
                <span class="material-symbols-outlined">warning</span>
                <span class="menu-text">Inadimplência</span>
            </a>
        </li>
      
        <li>
            <a href="descontos.php">
                <span class="material-symbols-outlined">local_offer</span>
                <span class="menu-text">Descontos/Bolsas</span>
            </a>
        </li>
        
        <li>
           <a href="controle-propinas.php">
                            <span class="material-symbols-outlined">block</span>
                            <span class="menu-text">Controle de Propinas</span>
                        </a>
        </li>
      
    </ul>
</nav>
            <div class="sidebar-footer">
                <a href="configuracoes.php">
                    <span class="material-symbols-outlined">settings</span>
                    <span class="menu-text">Configurações</span>
                </a>
                <a href="logout.php" class="logout">
                    <span class="material-symbols-outlined">logout</span>
                    <span class="menu-text">Sair</span>
                </a>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="content">
            <header class="top-bar">
                <div class="search-container">
                    <span class="material-symbols-outlined">search</span>
                    <input type="text" placeholder="Pesquisar transações, alunos...">
                </div>
                <div class="top-bar-actions">
                    <span class="material-symbols-outlined notification">notifications</span>
                    <span class="material-symbols-outlined">help</span>
                </div>
            </header>

            <div class="dashboard-content">
                <div class="welcome-section">
                    <div class="welcome-text">
    <h1>Gestão Financeira Escolar</h1>
  <p>Período: <strong id="current-month-year"></strong> | Ano Letivo <strong>2025</strong> | <strong><?php echo $totalAlunos; ?> alunos matriculados</strong></p>
<script> document.getElementById('current-month-year').textContent = new Date().toLocaleDateString('pt-PT', {month: 'long', year: 'numeric'}); </script>
</div>
                    <div class="welcome-actions">
                        <button class="btn-primary">
                            <span class="material-symbols-outlined">add</span>
                            Nova Transação
                        </button>
                    </div>
                </div>

                <!-- Stats Cards -->
                <div class="stats-container">
    <div class="stat-card">
        <div class="stat-icon" style="background-color: rgba(76, 175, 80, 0.1);">
            <span class="material-symbols-outlined" style="color: #4caf50;">payments</span>
        </div>
        <div class="stat-info">
            <h3>AOA 1.059.950,00</h3>
            <p>Mensalidades Recebidas (Mês)</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background-color: rgba(255, 152, 0, 0.1);">
            <span class="material-symbols-outlined" style="color: #ff9800;">schedule</span>
        </div>
        <div class="stat-info">
            <h3>AOA 127.450,00</h3>
            <p>Mensalidades Pendentes</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background-color: rgba(244, 67, 54, 0.1);">
            <span class="material-symbols-outlined" style="color: #f44336;">warning</span>
        </div>
        <div class="stat-info">
            <h3>AOA 45.200,00</h3>
            <p>Inadimplência (63 alunos)</p>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background-color: rgba(33, 150, 243, 0.1);">
            <span class="material-symbols-outlined" style="color: #2196f3;">person_add</span>
        </div>
        <div class="stat-info">
            <h3>28</h3>
            <p>Novas Matrículas (Mês)</p>
        </div>
    </div>
</div>

                <div class="dashboard-grid">
                    <!-- Mensalidades Pendentes -->
                    <div class="dashboard-card">
                        <div class="card-header">
                            <h2>Mensalidades Pendentes</h2>
                            <a href="mensalidades.php" class="view-all">Ver todas</a>
                        </div>
                        <div class="card-content">
                            <div class="table-container">
                                <table class="data-table">
                                    <thead>
                                        <tr>
                                            <th>Aluno</th>
                                            <th>Turma</th>
                                            <th>Vencimento</th>
                                            <th>Valor</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>
                                                <div class="student-name">
                                                    <img src="https://via.placeholder.com/40" alt="Aluno">
                                                    <div>
                                                        <p>João Silva</p>
                                                        <span class="text-muted">Matrícula: 2025001</span>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>9º Ano A</td>
                                            <td>15/04/2025</td>
                                            <td>AOA 850,00</td>
                                            <td><span class="status-badge inactive">Vencida</span></td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="student-name">
                                                    <img src="https://via.placeholder.com/40" alt="Aluno">
                                                    <div>
                                                        <p>Maria Santos</p>
                                                        <span class="text-muted">Matrícula: 2025002</span>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>8º Ano B</td>
                                            <td>20/04/2025</td>
                                            <td>AOA 850,00</td>
                                            <td><span class="status-badge" style="background-color: rgba(255, 152, 0, 0.1); color: #ff9800;">Pendente</span></td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="student-name">
                                                    <img src="https://via.placeholder.com/40" alt="Aluno">
                                                    <div>
                                                        <p>Pedro Costa</p>
                                                        <span class="text-muted">Matrícula: 2025003</span>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>7º Ano C</td>
                                            <td>25/04/2025</td>
                                            <td>AOA 780,00</td>
                                            <td><span class="status-badge" style="background-color: rgba(255, 152, 0, 0.1); color: #ff9800;">Pendente</span></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <!-- Fluxo de Caixa -->
                    <div class="dashboard-card">
                        <div class="card-header">
                            <h2>Fluxo de Caixa (Últimos 7 dias)</h2>
                            <a href="fluxo-caixa.php" class="view-all">Ver detalhes</a>
                        </div>
                        <div class="card-content">
                            <div class="cashflow-chart">
                                <div class="cashflow-item">
                                    <div class="cashflow-date">
                                        <span class="day">15</span>
                                        <span class="month">Abr</span>
                                    </div>
                                    <div class="cashflow-details">
                                        <div class="cashflow-in">
                                            <span class="material-symbols-outlined">arrow_upward</span>
                                            <span>AOA 25.400,00</span>
                                        </div>
                                        <div class="cashflow-out">
                                            <span class="material-symbols-outlined">arrow_downward</span>
                                            <span>AOA 8.200,00</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="cashflow-item">
                                    <div class="cashflow-date">
                                        <span class="day">16</span>
                                        <span class="month">Abr</span>
                                    </div>
                                    <div class="cashflow-details">
                                        <div class="cashflow-in">
                                            <span class="material-symbols-outlined">arrow_upward</span>
                                            <span>AOA 18.750,00</span>
                                        </div>
                                        <div class="cashflow-out">
                                            <span class="material-symbols-outlined">arrow_downward</span>
                                            <span>AOA 12.300,00</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="cashflow-item">
                                    <div class="cashflow-date">
                                        <span class="day">17</span>
                                        <span class="month">Abr</span>
                                    </div>
                                    <div class="cashflow-details">
                                        <div class="cashflow-in">
                                            <span class="material-symbols-outlined">arrow_upward</span>
                                            <span>AOA 32.100,00</span>
                                        </div>
                                        <div class="cashflow-out">
                                            <span class="material-symbols-outlined">arrow_downward</span>
                                            <span>AOA 15.600,00</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Receitas por Categoria -->
                    <div class="dashboard-card">
                        <div class="card-header">
                            <h2>Receitas por Categoria</h2>
                            <a href="receitas.php" class="view-all">Ver todas</a>
                        </div>
                        <div class="card-content">
                            <div class="revenue-categories">
                                <div class="category-item">
                                    <div class="category-info">
                                        <div class="category-icon" style="background-color: rgba(74, 111, 220, 0.1);">
                                            <span class="material-symbols-outlined" style="color: #4a6fdc;">school</span>
                                        </div>
                                        <div>
                                            <h4>Mensalidades</h4>
                                            <p>AOA 420.500,00</p>
                                        </div>
                                    </div>
                                    <div class="category-percentage">86.5%</div>
                                </div>
                                <div class="category-item">
                                    <div class="category-info">
                                        <div class="category-icon" style="background-color: rgba(76, 175, 80, 0.1);">
                                            <span class="material-symbols-outlined" style="color: #4caf50;">restaurant</span>
                                        </div>
                                        <div>
                                            <h4>Cantina</h4>
                                            <p>AOA 35.200,00</p>
                                        </div>
                                    </div>
                                    <div class="category-percentage">7.2%</div>
                                </div>
                                <div class="category-item">
                                    <div class="category-info">
                                        <div class="category-icon" style="background-color: rgba(255, 152, 0, 0.1);">
                                            <span class="material-symbols-outlined" style="color: #ff9800;">book</span>
                                        </div>
                                        <div>
                                            <h4>Material Didático</h4>
                                            <p>AOA 18.750,00</p>
                                        </div>
                                    </div>
                                    <div class="category-percentage">3.9%</div>
                                </div>
                                <div class="category-item">
                                    <div class="category-info">
                                        <div class="category-icon" style="background-color: rgba(156, 39, 176, 0.1);">
                                            <span class="material-symbols-outlined" style="color: #9c27b0;">event</span>
                                        </div>
                                        <div>
                                            <h4>Eventos</h4>
                                            <p>AOA 11.300,00</p>
                                        </div>
                                    </div>
                                    <div class="category-percentage">2.4%</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Alertas Financeiros -->
                    <div class="dashboard-card">
                        <div class="card-header">
                            <h2>Alertas Financeiros</h2>
                            <a href="alertas.php" class="view-all">Ver todos</a>
                        </div>
                        <div class="card-content">
                            <div class="alerts-list">
                                <div class="alert-item">
                                    <div class="alert-icon" style="background-color: rgba(244, 67, 54, 0.1);">
                                        <span class="material-symbols-outlined" style="color: #f44336;">warning</span>
                                    </div>
                                    <div class="alert-content">
                                        <h4>15 mensalidades vencidas</h4>
                                        <p>Total de AOA 12.750,00 em atraso</p>
                                        <span class="alert-time">Hoje</span>
                                    </div>
                                </div>
                                <div class="alert-item">
                                    <div class="alert-icon" style="background-color: rgba(255, 152, 0, 0.1);">
                                        <span class="material-symbols-outlined" style="color: #ff9800;">schedule</span>
                                    </div>
                                    <div class="alert-content">
                                        <h4>Pagamento de fornecedores</h4>
                                        <p>Vencimento em 3 dias - AOA 25.400,00</p>
                                        <span class="alert-time">18/04/2025</span>
                                    </div>
                                </div>
                                <div class="alert-item">
                                    <div class="alert-icon" style="background-color: rgba(33, 150, 243, 0.1);">
                                        <span class="material-symbols-outlined" style="color: #2196f3;">info</span>
                                    </div>
                                    <div class="alert-content">
                                        <h4>Relatório mensal disponível</h4>
                                        <p>Relatório de março já pode ser gerado</p>
                                        <span class="alert-time">Ontem</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script>
        // Toggle sidebar on mobile
        document.getElementById('menuToggle').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('collapsed');
            document.querySelector('.content').classList.toggle('expanded');
        });

        // Simular dados em tempo real
        function updateStats() {
            // Aqui você pode adicionar lógica para atualizar os dados em tempo real
            console.log('Atualizando estatísticas...');
        }

        // Atualizar a cada 30 segundos
        setInterval(updateStats, 30000);
    </script>
</body>
</html>
<?php }else{
    header("Location: ../login.php");
    exit;
} ?>