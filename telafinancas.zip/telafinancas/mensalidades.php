<?php
session_start();

// Verificar se o usuário está logado
if (!isset($_SESSION['id']) || !isset($_SESSION['role'])) {
    header("Location: ../login.php");
    exit;
}

include('../dbconnection.php');

// Inicializar variáveis para mensagens
$_SESSION['error'] = '';
$_SESSION['success'] = '';

// Buscar lista de alunos (da tabela oficial 'estudantes')
$alunosStmt = $conn->prepare("SELECT id, fname, lname FROM estudantes ORDER BY lname, fname");
$alunosStmt->execute();
$alunos = $alunosStmt->fetchAll(PDO::FETCH_ASSOC);

// Buscar lista de turmas
$sqlTurmas = "SELECT id, class_name FROM turma ORDER BY class_name";
$stmtTurmas = $conn->query($sqlTurmas);
$turmas = $stmtTurmas->fetchAll(PDO::FETCH_ASSOC);

// Processar o formulário quando enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_fee'])) {
    // Coletar e sanitizar dados do formulário
    $estudante_id = filter_input(INPUT_POST, 'aluno', FILTER_VALIDATE_INT);
    $turma_id = filter_input(INPUT_POST, 'turma', FILTER_VALIDATE_INT);
    $data_vencimento = filter_input(INPUT_POST, 'data_vencimento', FILTER_SANITIZE_STRING);
    $valor = filter_input(INPUT_POST, 'valor', FILTER_VALIDATE_FLOAT);
    $status = strtolower(trim($_POST['status'])); // convertendo para lowercase
    $data_pagamento = !empty($_POST['data_pagamento']) ? filter_input(INPUT_POST, 'data_pagamento', FILTER_SANITIZE_STRING) : null;

    // Obter mês e ano com base na data de vencimento
    $mes = date('F', strtotime($data_vencimento)); // Ex: 'May'
    $ano = date('Y', strtotime($data_vencimento));

    // Validação
    if (empty($estudante_id)) {
        $_SESSION['error'] = "Selecione um aluno válido.";
    } elseif (empty($turma_id)) {
        $_SESSION['error'] = "Selecione uma turma válida.";
    } elseif (empty($data_vencimento)) {
        $_SESSION['error'] = "Data de vencimento é obrigatória.";
    } elseif (empty($valor) || $valor <= 0) {
        $_SESSION['error'] = "Valor deve ser maior que zero.";
    } else {
        try {
            // Inserção na tabela mensalidades
            $sql = "INSERT INTO mensalidades (
                        estudante_id, turma_id, mes, ano, valor, data_vencimento, status, data_pagamento
                    ) VALUES (
                        :estudante_id, :turma_id, :mes, :ano, :valor, :data_vencimento, :status, :data_pagamento
                    )";

            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':estudante_id', $estudante_id, PDO::PARAM_INT);
            $stmt->bindParam(':turma_id', $turma_id, PDO::PARAM_INT);
            $stmt->bindParam(':mes', $mes);
            $stmt->bindParam(':ano', $ano);
            $stmt->bindParam(':valor', $valor);
            $stmt->bindParam(':data_vencimento', $data_vencimento);
            $stmt->bindParam(':status', $status);
            $stmt->bindParam(':data_pagamento', $data_pagamento);

            if ($stmt->execute()) {
                $_SESSION['success'] = "Mensalidade efetuada com sucesso!";
                header("Location: ".$_SERVER['PHP_SELF']);
                exit();
            } else {
                $_SESSION['error'] = "Erro ao adicionar mensalidade.";
            }
        } catch (PDOException $e) {
            $_SESSION['error'] = "Erro no banco de dados: " . $e->getMessage();
        }
    }
}

// Buscar listagem de mensalidades
try {
    $mensalidadesStmt = $conn->prepare("
        SELECT 
            m.id, 
            m.estudante_id,  -- Adicionando esta linha para pegar o ID do estudante como estudante_id
            e.fname, 
            e.lname, 
            t.class_name, 
            t.class_grade, 
            m.data_vencimento, 
            m.valor, 
            m.status, 
            m.data_pagamento
        FROM mensalidades m
        LEFT JOIN estudantes e ON m.estudante_id = e.id
        LEFT JOIN turma t ON m.turma_id = t.id
        ORDER BY m.data_vencimento DESC
    ");
    $mensalidadesStmt->execute();
    $mensalidades = $mensalidadesStmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $mensalidades = [];
    $_SESSION['error'] = "Erro ao buscar mensalidades: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mensalidades - Dashboard Financeiro</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <style>
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        
        .modal-content {
            background: white;
            padding: 20px;
            border-radius: 8px;
            max-width: 500px;
            margin: 50px auto;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        
        .close-modal {
            float: right;
            cursor: pointer;
            font-size: 24px;
            font-weight: bold;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .scrollable-table {
            max-height: 500px;
            overflow-y: auto;
            border: 1px solid #ddd;
            border-radius: 4px;
            margin-bottom: 20px;
        }
        
        .scrollable-table table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .scrollable-table thead th {
            position: sticky;
            top: 0;
            background: white;
            z-index: 10;
            box-shadow: 0 2px 2px -1px rgba(0, 0, 0, 0.1);
        }
        
        .modal-footer {
            text-align: right;
            margin-top: 20px;
        }
        
        .status-badge {
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .status-badge.active {
            background-color: #e8f5e9;
            color: #2e7d32;
        }
        
        .status-badge.pending {
            background-color: #fff8e1;
            color: #ff8f00;
        }
        
        .status-badge.inactive {
            background-color: #ffebee;
            color: #c62828;
        }
        
        .alert {
            padding: 12px 16px;
            border-radius: 4px;
            margin-bottom: 16px;
        }
        
        .alert-success {
            background-color: #e8f5e9;
            color: #2e7d32;
            border: 1px solid #c8e6c9;
        }
        
        .alert-error {
            background-color: #ffebee;
            color: #c62828;
            border: 1px solid #ffcdd2;
        }

         /* Estilos para o modal */
    .modal {
        display: none;
        position: fixed;
        z-index: 1000;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        overflow: auto;
        animation: fadeIn 0.3s;
    }

    .modal-content {
        background-color: #fff;
        margin: 5% auto;
        padding: 0;
        border-radius: 8px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
        width: 90%;
        max-width: 600px;
        overflow: hidden;
    }

    .modal-header {
        padding: 20px 24px;
        background-color: #4a6baf;
        color: white;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .modal-header h2 {
        margin: 0;
        font-size: 1.5rem;
        font-weight: 600;
    }

    .close-modal {
        font-size: 28px;
        font-weight: bold;
        cursor: pointer;
        transition: color 0.2s;
    }

    .close-modal:hover {
        color: #d1d1d1;
    }

    .modal-form {
        padding: 24px;
    }

    .form-row {
        display: flex;
        gap: 16px;
        margin-bottom: 16px;
    }

    .form-group {
        flex: 1;
        margin-bottom: 8px;
    }

    .form-group label {
        display: block;
        margin-bottom: 8px;
        font-weight: 500;
        color: #333;
        font-size: 0.9rem;
    }

    .form-control {
        width: 100%;
        padding: 10px 12px;
        border: 1px solid #ddd;
        border-radius: 4px;
        font-size: 0.9rem;
        transition: border-color 0.3s, box-shadow 0.3s;
    }

    .form-control:focus {
        border-color: #4a6baf;
        box-shadow: 0 0 0 2px rgba(74, 107, 175, 0.2);
        outline: none;
    }

    .input-with-icon {
        position: relative;
    }

    .input-with-icon .currency-symbol {
        position: absolute;
        left: 12px;
        top: 50%;
        transform: translateY(-50%);
        color: #666;
    }

    .input-with-icon input {
        padding-left: 30px;
    }

    .modal-footer {
        display: flex;
        justify-content: flex-end;
        padding: 16px 24px;
        background-color: #f9f9f9;
        border-top: 1px solid #eee;
    }

    .btn {
        padding: 10px 20px;
        border-radius: 4px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.2s;
        border: 1px solid transparent;
    }

    .btn-primary {
        background-color: #4a6baf;
        color: white;
    }

    .btn-primary:hover {
        background-color: #3a5a9f;
    }

    .btn-outline {
        background-color: transparent;
        border-color: #ccc;
        color: #333;
    }

    .btn-outline:hover {
        background-color: #f5f5f5;
    }

    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }

    /* Responsividade */
    @media (max-width: 768px) {
        .form-row {
            flex-direction: column;
            gap: 0;
        }
        
        .modal-content {
            margin: 10% auto;
            width: 95%;
        }
    }
    </style>
</head>
<body>
    <div class="container">
        <!-- Sidebar Menu -->
        <aside class="sidebar">
             <div class="sidebar-header">
                <h2>Pitruca <br>Camama</h2>
                <span class="material-symbols-outlined menu-toggle" id="menuToggle">menu</span>
            </div>
            <div class="profile">
                <div class="profile-info">
                    <span><?php echo $_SESSION['fname']; ?></span>
                    <p>Gerente Financeiro</p>
                </div>
            </div>
            <nav class="menu">
                <ul>
                    <li>
                        <a href="index.php">
                            <span class="material-symbols-outlined">dashboard</span>
                            <span class="menu-text">Dashboard</span>
                        </a>
                    </li>
                    <li class="active">
                        <a href="mensalidades.php">
                            <span class="material-symbols-outlined">payments</span>
                            <span class="menu-text">Mensalidades</span>
                        </a>
                    </li>
                    <li>
                        <a href="inadimplencia.php">
                            <span class="material-symbols-outlined">warning</span>
                            <span class="menu-text">Inadimplência</span>
                        </a>
                    </li>
                    <li>
                        <a href="descontos.php">
                            <span class="material-symbols-outlined">local_offer</span>
                            <span class="menu-text">Descontos/Bolsas</span>
                        </a>
                    </li>
                    <li>
                       <a href="controle-propinas.php">
                            <span class="material-symbols-outlined">block</span>
                            <span class="menu-text">Controle de Propinas</span>
                        </a>
                    </li>
                </ul>
            </nav>
            <div class="sidebar-footer">
                <a href="configuracoes.php">
                    <span class="material-symbols-outlined">settings</span>
                    <span class="menu-text">Configurações</span>
                </a>
                <a href="logout.php" class="logout">
                    <span class="material-symbols-outlined">logout</span>
                    <span class="menu-text">Sair</span>
                </a>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="content">
            <header class="top-bar">
                <div class="search-container">
                    <span class="material-symbols-outlined">search</span>
                    <input type="text" placeholder="Pesquisar aluno, matrícula...">
                </div>
                <div class="top-bar-actions">
                    <span class="material-symbols-outlined notification">notifications</span>
                    <span class="material-symbols-outlined">help</span>
                </div>
            </header>

            <div class="dashboard-content">
                <!-- Exibir mensagens de sucesso/erro -->
                <?php if (!empty($_SESSION['success'])): ?>
                    <div class="alert alert-success">
                        <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                    </div>
                <?php endif; ?>
                
                <?php if (!empty($_SESSION['error'])): ?>
                    <div class="alert alert-error">
                        <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                    </div>
                <?php endif; ?>

                <div class="page-header">
                    <div>
                        <h1>Gestão de Mensalidades</h1>
                        <p>Controle completo das mensalidades escolares</p>
                    </div>
                    <div class="page-actions">
                        <button class="btn-outline">
                            <span class="material-symbols-outlined">download</span>
                            Exportar
                        </button>
                       <button id="generateFeesBtn" class="btn-primary">
                            <span class="material-symbols-outlined">add_circle</span>
                            Nova Mensalidade
                        </button>
                    </div>
                </div>

                <!-- Stats Cards -->
                <div class="stats-container">
                    <div class="stat-card">
                        <div class="stat-icon" style="background-color: rgba(76, 175, 80, 0.1);">
                            <span class="material-symbols-outlined" style="color: #4caf50;">check_circle</span>
                        </div>
                        <div class="stat-info">
                            <h3>1.184</h3>
                            <p>Mensalidades Pagas</p>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon" style="background-color: rgba(255, 152, 0, 0.1);">
                            <span class="material-symbols-outlined" style="color: #ff9800;">schedule</span>
                        </div>
                        <div class="stat-info">
                            <h3>149</h3>
                            <p>Mensalidades Pendentes</p>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon" style="background-color: rgba(244, 67, 54, 0.1);">
                            <span class="material-symbols-outlined" style="color: #f44336;">error</span>
                        </div>
                        <div class="stat-info">
                            <h3>63</h3>
                            <p>Mensalidades Vencidas</p>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon" style="background-color: rgba(33, 150, 243, 0.1);">
                            <span class="material-symbols-outlined" style="color: #2196f3;">payments</span>
                        </div>
                        <div class="stat-info">
                            <h3>AOA 1.059.950</h3>
                            <p>Total Arrecadado</p>
                        </div>
                    </div>
                </div>

                <!-- Filters -->
                <div class="filter-container">
                    <div class="filter-group">
                        <label>Turma:</label>
                        <select class="filter-select">
                            <option>Todas as turmas</option>
                            <option>1º Ano A</option>
                            <option>2º Ano A</option>
                            <option>3º Ano A</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label>Status:</label>
                        <select class="filter-select">
                            <option>Todos os status</option>
                            <option>Pago</option>
                            <option>Pendente</option>
                            <option>Vencido</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label>Mês:</label>
                        <select class="filter-select">
                            <option>Abril 2025</option>
                            <option>Março 2025</option>
                            <option>Fevereiro 2025</option>
                        </select>
                    </div>
                    <button class="btn-primary">
                        <span class="material-symbols-outlined">filter_list</span>
                        Filtrar
                    </button>
                </div>

                <!-- Mensalidades Table -->
                <div class="scrollable-table">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Aluno</th>
                                <th>Turma</th>
                                <th>Prazo</th>
                                <th>Valor</th>
                                <th>Estado</th>
                                <th>Pagamento</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($mensalidades as $mensalidade): ?>
                                    <?php
                                    $status = isset($mensalidade['status']) ? $mensalidade['status'] : 'indefinido';

                                if ($status == 'Pago') {
                                    $statusClass = 'active';
                                } elseif ($status == 'Pendente') {
                                    $statusClass = 'pending';
                                } else {
                                    $statusClass = 'inactive';
                                }?>
                                <tr>
                                    <td>
                                        <div class="student-name">
                                        <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($mensalidade['fname'] . ' ' . $mensalidade['lname']); ?>&background=random" alt="Aluno" style="width: 40px; height: 40px; border-radius: 50%;">
                                        <div>
                                            <p><?php echo htmlspecialchars($mensalidade['fname'] . ' ' . $mensalidade['lname']); ?></p>
                                        </div>
                                    </div>

                                    </td>
                                    <td><?php echo htmlspecialchars($mensalidade['class_name']); ?></td>
                                    <td><?php echo date('d/m/Y', strtotime($mensalidade['data_vencimento'])); ?></td>
                                    <td>AOA <?php echo number_format($mensalidade['valor'], 2, ',', '.'); ?></td>
                                    <td><span class="status-badge <?php echo $statusClass; ?>"><?php echo htmlspecialchars($mensalidade['status']); ?></span></td>
                                    <td><?php echo $mensalidade['data_pagamento'] ? date('d/m/Y', strtotime($mensalidade['data_pagamento'])) : '-'; ?></td>
                                    <td>
                                        <div class="actions">
                                            <button class="action-btn">
                                                <span class="material-symbols-outlined">visibility</span>
                                            </button>
                                            <button class="action-btn">
                                                <span class="material-symbols-outlined">print</span>
                                            </button>
                                            <?php if ($mensalidade['status'] == 'Pendente'): ?>
                                                <button class="action-btn pay-btn" data-id="<?php echo $mensalidade['id']; ?>">
                                                    <span class="material-symbols-outlined" style="color: #4caf50;">payments</span>
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <div class="pagination">
                    <button class="pagination-btn" disabled>
                        <span class="material-symbols-outlined">chevron_left</span>
                    </button>
                    <button class="pagination-btn active">1</button>
                    <button class="pagination-btn">2</button>
                    <button class="pagination-btn">3</button>
                    <span class="pagination-ellipsis">...</span>
                    <button class="pagination-btn">15</button>
                    <button class="pagination-btn">
                        <span class="material-symbols-outlined">chevron_right</span>
                    </button>
                </div>
            </div>
        </main>
    </div>

    <!-- Modal para Nova Mensalidade -->
<div id="newFeeModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Nova Mensalidade</h2>
            <span class="close-modal" id="closeFeeModal">&times;</span>
        </div>
        
        <form method="POST" action="" class="modal-form">
            <div class="form-row">
                <div class="form-group">
                    <label for="aluno">Aluno:</label>
                    <select id="aluno" name="aluno" class="form-control" required>
                        <option value="">Selecione o aluno</option>
                        <?php foreach ($alunos as $aluno): ?>
                            <option value="<?php echo $aluno['id']; ?>"><?php echo htmlspecialchars($aluno['fname'] . ' ' . $aluno['lname']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="turma">Turma:</label>
                    <select id="turma" name="turma" class="form-control" required>
                        <option value="">Selecione a turma</option>
                        <?php foreach ($turmas as $turma): ?>
                            <option value="<?php echo $turma['id']; ?>"><?php echo htmlspecialchars($turma['class_name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="valor">Valor (AOA):</label>
                    <div class="input-with-icon">
                        <input type="number" id="valor" name="valor" step="0.01" min="0" class="form-control" placeholder="0,00" required>
                        <span class="currency-symbol">Kz</span>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="data_vencimento">Data de Vencimento:</label>
                    <input type="date" id="data_vencimento" name="data_vencimento" class="form-control" required>
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label for="status">Status:</label>
                    <select id="status" name="status" class="form-control" required>
                        <option value="Pendente" selected>Pendente</option>
                        <option value="Pago">Pago</option>
                        <option value="Vencido">Vencido</option>
                    </select>
                </div>
                
                <div class="form-group" id="dataPagamentoGroup" style="display: none;">
                    <label for="data_pagamento">Data de Pagamento:</label>
                    <input type="date" id="data_pagamento" name="data_pagamento" class="form-control">
                </div>
            </div>
            
            <div class="modal-footer">
                <button type="button" id="cancelFee" class="btn btn-outline">Cancelar</button>
                <button type="submit" name="submit_fee" class="btn btn-primary">Salvar Mensalidade</button>
            </div>
        </form>
    </div>
</div>


<script>
// Script para mostrar/ocultar campo de data de pagamento conforme o status
document.getElementById('status').addEventListener('change', function() {
    const paymentDateGroup = document.getElementById('dataPagamentoGroup');
    if (this.value === 'Pago') {
        paymentDateGroup.style.display = 'block';
    } else {
        paymentDateGroup.style.display = 'none';
    }
});
</script>

    <script>
        // Controle do modal
        const modal = document.getElementById('newFeeModal');
        const openBtn = document.getElementById('generateFeesBtn');
        const closeBtn = document.getElementById('closeFeeModal');
        const cancelBtn = document.getElementById('cancelFee');
        const statusSelect = document.getElementById('status');
        const dataPagamentoGroup = document.getElementById('dataPagamentoGroup');

        // Abrir modal
        openBtn.addEventListener('click', () => {
            modal.style.display = 'block';
        });

        // Fechar modal
        closeBtn.addEventListener('click', () => {
            modal.style.display = 'none';
        });

        cancelBtn.addEventListener('click', () => {
            modal.style.display = 'none';
        });

        // Fechar modal ao clicar fora
        window.addEventListener('click', (event) => {
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        });

        // Mostrar/ocultar campo de data de pagamento conforme status
        statusSelect.addEventListener('change', () => {
            if (statusSelect.value === 'Pago') {
                dataPagamentoGroup.style.display = 'block';
                // Definir data atual como padrão
                document.getElementById('data_pagamento').valueAsDate = new Date();
            } else {
                dataPagamentoGroup.style.display = 'none';
                document.getElementById('data_pagamento').value = '';
            }
        });

        // Definir data de vencimento padrão para 5 dias à frente
        document.getElementById('data_vencimento').valueAsDate = new Date(Date.now() + 5 * 24 * 60 * 60 * 1000);
    </script>
</body>
</html>